import mongoose from 'mongoose';
const { ObjectId } = mongoose.Types;

export const globalImport = {
  ObjectId: ObjectId,
};
