export const RUNCONTEST_SEARCHABLE_FIELDS = ['name', 'header_1', 'title'];
export const RUNCONTEST_FILTERABLE_FIELDS = [
  'searchTerm',
  'lessonId',
  'courseId',
  'date',
  'select',
  'status',
];
