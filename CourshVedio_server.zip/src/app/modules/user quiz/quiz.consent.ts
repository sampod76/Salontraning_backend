export const QUIZ_SEARCHABLE_FIELDS = [
  'courseId',
  'title',
  'description',
  'header_1',
  'header_2',
  'tag',
];
export const QUIZ_FILTERABLE_FIELDS = ['searchTerm', 'courseId', 'date'];
