export const moderatorFilterableFields = [
  'searchTerm',
  'id',
  'gender',
  'email',
  'phone',
  'emergencyphone',
  'designation',
  'status',
];

export const moderatorSearchableFields = [
  'email',
  'phone',
  'emergencyphone',
  'name.firstName',
  'name.lastName',
  'name.middleName',
];
