export const PURCHASED_COURSES_SEARCHABLE_FIELDS = [
  'lessonId',
  'courseId',
  'title',
  'description',
  'header_1',
  'header_2',
  'tag',
];
export const PURCHASED_COURSES_FILTERABLE_FIELDS = [
  'searchTerm',
  'lessonId',
  'courseId',
  'date',
];
