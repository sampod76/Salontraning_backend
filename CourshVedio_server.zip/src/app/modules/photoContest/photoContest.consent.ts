export const PHOTOCONTEST_USER_SEARCHABLE_FIELDS = ['name', 'email', 'phone'];
export const PHOTOCONTEST_USER_FILTERABLE_FIELDS = [
  'searchTerm',
  'status',
  'winnerData',
  'date',
  'status',
  'contest',
];
