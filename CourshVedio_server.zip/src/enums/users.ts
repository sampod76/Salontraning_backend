export enum ENUM_USER_ROLE {
  SUPER_ADMIN = 'admin',
  ADMIN = 'admin',
  GENERAL_USER = 'general-user',
  MODERATOR = 'moderator',
}
